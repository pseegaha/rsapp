# USA COVID-19 Tracker

A very basic tracker for assessing confirmed COVID-19 cases per capita in counties in each state.

https://covid.justinsingh.me
